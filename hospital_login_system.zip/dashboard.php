<?php
session_start();
if(!isset($_SESSION['user'])){
    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-dark bg-dark">
<div class="container">
<a class="navbar-brand">Hospital System</a>
<a href="logout.php" class="btn btn-danger">Logout</a>
</div>
</nav>

<div class="container mt-5">
<h2>Welcome, <?php echo $_SESSION['user']; ?></h2>

<div class="card mt-3 p-3">
<h5>Hospital Management Dashboard</h5>
<ul>
<li>Manage Patients</li>
<li>Manage Doctors</li>
<li>Appointments</li>
<li>Records</li>
</ul>
</div>

</div>

</body>
</html>
