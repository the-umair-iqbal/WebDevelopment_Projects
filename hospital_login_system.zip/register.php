<?php
include("config.php");

if(isset($_POST['register'])){
    $name = $_POST['fullname'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO users(fullname,email,password) VALUES('$name','$email','$password')";
    if($conn->query($sql)){
        echo "Registered successfully. <a href='index.php'>Login</a>";
    } else {
        echo "Error";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Register</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
<div class="row justify-content-center">
<div class="col-md-4">

<h3 class="text-center">Register</h3>

<form method="POST">
<input type="text" name="fullname" class="form-control mb-2" placeholder="Full Name" required>
<input type="email" name="email" class="form-control mb-2" placeholder="Email" required>
<input type="password" name="password" class="form-control mb-2" placeholder="Password" required>
<button class="btn btn-success w-100" name="register">Sign Up</button>
</form>

</div>
</div>
</div>

</body>
</html>
