<?php
$conn = new mysqli("localhost","root","","cinema_booking");
if($conn->connect_error){
die("Connection failed");
}
?>
