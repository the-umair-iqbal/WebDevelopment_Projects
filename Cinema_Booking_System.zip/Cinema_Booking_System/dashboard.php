<?php
session_start();
include 'db.php';

if(!isset($_SESSION['user'])){
header("Location: login.php");
}

if(isset($_POST['add_movie'])){

$movie=$_POST['movie_name'];
$genre=$_POST['genre'];
$time=$_POST['show_time'];
$price=$_POST['ticket_price'];
$seats=$_POST['seats'];
$user=$_SESSION['user'];

$conn->query("INSERT INTO movies(movie_name,genre,show_time,ticket_price,seats,created_by)
VALUES('$movie','$genre','$time','$price','$seats','$user')");
}

if(isset($_GET['delete'])){

$id=$_GET['delete'];

$conn->query("DELETE FROM movies WHERE id=$id");
}

$movies=$conn->query("SELECT * FROM movies");
?>

<!DOCTYPE html>
<html>
<head>

<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>
<link rel='stylesheet' href='style.css'>
<script src='script.js'></script>

</head>

<body>

<div class='container mt-5'>

<div class='card mb-4'>

<h2>Welcome <?php echo $_SESSION['user']; ?></h2>

<form method='POST'>

<input type='text' name='movie_name' class='form-control mb-3' placeholder='Movie Name' required>

<input type='text' name='genre' class='form-control mb-3' placeholder='Genre' required>

<input type='text' name='show_time' class='form-control mb-3' placeholder='Show Time' required>

<input type='number' name='ticket_price' class='form-control mb-3' placeholder='Ticket Price' required>

<input type='number' name='seats' class='form-control mb-3' placeholder='Seats' required>

<button type='submit' name='add_movie' class='btn btn-custom'>Add Movie</button>

<a href='logout.php' class='btn btn-danger'>Logout</a>

</form>

</div>

<div class='table-box'>

<table class='table table-bordered text-white'>

<tr>
<th>ID</th>
<th>Movie</th>
<th>Genre</th>
<th>Time</th>
<th>Price</th>
<th>Seats</th>
<th>User</th>
<th>Delete</th>
</tr>

<?php while($row=$movies->fetch_assoc()){ ?>

<tr>

<td><?php echo $row['id']; ?></td>
<td><?php echo $row['movie_name']; ?></td>
<td><?php echo $row['genre']; ?></td>
<td><?php echo $row['show_time']; ?></td>
<td><?php echo $row['ticket_price']; ?></td>
<td><?php echo $row['seats']; ?></td>
<td><?php echo $row['created_by']; ?></td>

<td>
<a href='?delete=<?php echo $row['id']; ?>'
class='btn btn-danger btn-sm'
onclick='return confirmDelete()'>
Delete
</a>
</td>

</tr>

<?php } ?>

</table>

</div>

</div>

</body>
</html>
