<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<title>Cinema Booking</title>
<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>
<link rel='stylesheet' href='style.css'>
</head>
<body class='d-flex justify-content-center align-items-center'>
<div class='card text-center' style='width:450px'>
<h1 class='mb-4'>Cinema Booking System</h1>
<a href='signup.php' class='btn btn-custom mb-3'>Signup</a>
<a href='login.php' class='btn btn-light'>Login</a>
</div>
</body>
</html>
