CREATE DATABASE IF NOT EXISTS cinema_booking;
USE cinema_booking;

CREATE TABLE users(
id INT AUTO_INCREMENT PRIMARY KEY,
fullname VARCHAR(100),
email VARCHAR(100) UNIQUE,
password VARCHAR(255)
);

CREATE TABLE movies(
id INT AUTO_INCREMENT PRIMARY KEY,
movie_name VARCHAR(100),
genre VARCHAR(100),
show_time VARCHAR(100),
ticket_price DECIMAL(10,2),
seats INT,
created_by VARCHAR(100)
);
