CINEMA BOOKING SYSTEM

1. Start Apache and MySQL in XAMPP
2. Put this folder in C:/xampp/htdocs/
3. Open phpMyAdmin
4. Create database: cinema_booking
5. Import database.sql
6. Run:
http://localhost/Cinema_Booking_System
