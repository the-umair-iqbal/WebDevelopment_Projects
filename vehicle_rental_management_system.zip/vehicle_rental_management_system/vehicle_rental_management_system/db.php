
<?php
$conn = new mysqli("localhost", "root", "", "vehicle_rental_db");

if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}
?>
