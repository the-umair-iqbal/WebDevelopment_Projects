
<?php
session_start();
include 'db.php';

if(!isset($_SESSION['user'])){
    header("Location: index.php");
    exit;
}

// Handle add vehicle
if(isset($_POST['add_vehicle'])){
    $vehicle = $_POST['vehicle'];
    $model = $_POST['model'];
    $rent = $_POST['rent'];

    $sql = "INSERT INTO vehicles(vehicle_name,model,rent_per_day)
            VALUES('$vehicle','$model','$rent')";

    $conn->query($sql);
    header("Location: dashboard.php");
    exit;
}

// Handle update vehicle
if(isset($_POST['update_vehicle'])){
    $id = $_POST['id'];
    $vehicle = $_POST['vehicle'];
    $model = $_POST['model'];
    $rent = $_POST['rent'];

    $conn->query("UPDATE vehicles
                   SET vehicle_name='$vehicle', model='$model', rent_per_day='$rent'
                   WHERE id=$id");

    header("Location: dashboard.php");
    exit;
}

// Handle delete vehicle
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    $conn->query("DELETE FROM vehicles WHERE id=$id");
    header("Location: dashboard.php");
    exit;
}

$editVehicle = null;
if(isset($_GET['edit'])){
    $id = $_GET['edit'];
    $res = $conn->query("SELECT * FROM vehicles WHERE id=$id");
    $editVehicle = $res && $res->num_rows > 0 ? $res->fetch_assoc() : null;
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">

    <div class="mb-3">
        <h1 class="dashboard-title">
            🚗 Vehicle Rental Dashboard
        </h1>
        <div class="text-center text-white" style="opacity:0.95;">
            Welcome <?php echo $_SESSION['user']; ?>
        </div>
    </div>


    <div class="text-end mb-3">
        <a href="logout.php" class="btn btn-danger">Logout</a>
    </div>

    <div class="card p-4 mb-4 card-box">
        <h3>Add Vehicle</h3>

        <form method="POST">
            <div class="row">
                <div class="col-md-4">
                    <input type="text" name="vehicle" class="form-control" placeholder="Vehicle Name" required>
                </div>

                <div class="col-md-4">
                    <input type="text" name="model" class="form-control" placeholder="Model" required>
                </div>

                <div class="col-md-4">
                    <input type="number" step="0.01" name="rent" class="form-control" placeholder="Rent Per Day" required>
                </div>
            </div>

            <button name="add_vehicle" class="btn btn-primary mt-3">
                Add Vehicle
            </button>
        </form>
    </div>

    <?php if ($editVehicle): ?>
        <div class="card p-4 mb-4 card-box" style="background: #f7f7f7;">
            <h3>Edit Vehicle</h3>

            <form method="POST">
                <input type="hidden" name="id" value="<?php echo $editVehicle['id']; ?>">

                <div class="row">
                    <div class="col-md-4">
                        <input type="text" name="vehicle" class="form-control" value="<?php echo $editVehicle['vehicle_name']; ?>" required>
                    </div>

                    <div class="col-md-4">
                        <input type="text" name="model" class="form-control" value="<?php echo $editVehicle['model']; ?>" required>
                    </div>

                    <div class="col-md-4">
                        <input type="number" step="0.01" name="rent" class="form-control" value="<?php echo $editVehicle['rent_per_day']; ?>" required>
                    </div>
                </div>

                <div class="d-flex gap-2 mt-3">
                    <button name="update_vehicle" class="btn btn-success">Save Changes</button>
                    <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    <?php endif; ?>

    <div class="table-container">
        <h3>Vehicle Records</h3>


        <table class="table table-bordered">
            <tr>
                <th>ID</th>
                <th>Vehicle</th>
                <th>Model</th>
                <th>Rent</th>
                <th>Action</th>
            </tr>

            <?php
            $result = $conn->query("SELECT * FROM vehicles");

            while($row = $result->fetch_assoc()){
            ?>

            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['vehicle_name']; ?></td>
                <td><?php echo $row['model']; ?></td>
                <td><?php echo $row['rent_per_day']; ?></td>

                <td>
                    <div class="d-flex gap-2">
                        <a href="?edit=<?php echo $row['id']; ?>"
                           class="btn btn-warning btn-sm">
                           Edit
                        </a>
                        <a href="?delete=<?php echo $row['id']; ?>"
                           class="btn btn-danger btn-sm">
                           Delete
                        </a>
                    </div>
                </td>
            </tr>


            <?php } ?>
        </table>
    </div>

</div>

</body>
</html>
