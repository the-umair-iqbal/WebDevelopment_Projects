
# Vehicle Rental Management System

## Requirements
- XAMPP
- PHP 8+
- MySQL

## Setup Steps
1. Copy the project folder into:
   htdocs/

2. Start Apache and MySQL from XAMPP.

3. Open phpMyAdmin:
   http://localhost/phpmyadmin

4. Create a database named:
   vehicle_rental_db

5. Import the SQL file:
   database.sql

6. Open in browser:
   http://localhost/vehicle_rental_management_system

## Features
- User Signup
- User Login
- Session Authentication
- Add Vehicle
- Delete Vehicle
- Logout
- Bootstrap UI
