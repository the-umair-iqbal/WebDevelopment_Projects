
console.log("Vehicle Rental Management System Loaded");
